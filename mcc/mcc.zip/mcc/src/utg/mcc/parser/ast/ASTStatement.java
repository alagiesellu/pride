package utg.mcc.parser.ast;

public abstract class ASTStatement extends ASTNode {

	// public boolean is_in_loop;
	//
	// public ASTStatement() {
	// is_in_loop = false;
	// }
	//
	// public void isInLoop(boolean flag) {
	// is_in_loop = flag;
	// }
}
