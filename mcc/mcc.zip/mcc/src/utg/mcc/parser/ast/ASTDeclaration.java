package utg.mcc.parser.ast;

public abstract class ASTDeclaration extends ASTNode {

}
