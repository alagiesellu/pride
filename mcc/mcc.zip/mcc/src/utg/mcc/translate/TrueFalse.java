package utg.mcc.translate;

public class TrueFalse {

  public String t;
  public String f;

  /**
   * @param t
   * @param f
   */
  public TrueFalse(String t, String f) {
    this.t = t;
    this.f = f;
  }
}