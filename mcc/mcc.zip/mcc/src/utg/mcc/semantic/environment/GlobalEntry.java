package utg.mcc.semantic.environment;

public class GlobalEntry extends Entry {

  public int globals = -1;

  public int locals = -1;

  public GlobalEntry() {
    super(null);
  }

}
