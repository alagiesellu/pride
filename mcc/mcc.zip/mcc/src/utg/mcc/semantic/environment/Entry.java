package utg.mcc.semantic.environment;

public abstract class Entry {

  public String name;

  public Entry(String name) {
    super();
    this.name = name;
  }
}
